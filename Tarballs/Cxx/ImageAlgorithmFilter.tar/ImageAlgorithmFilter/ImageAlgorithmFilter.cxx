#include <vtkImageData.h>
#include <vtkNew.h>

#include "vtkImageAlgorithmFilter.h"

void PrintImage(vtkImageData* image);

int main(int /* argc */, char* /* argv */[])
{
  vtkNew<vtkImageData> input;
  // Setup the image
  input->SetDimensions(2, 2, 1);
  input->AllocateScalars(VTK_DOUBLE, 1);

  // Fill every entry of the image data with "2.0"
  const int* dims = input->GetDimensions();

  for (int y = 0; y < dims[1]; y++)
  {
    for (int x = 0; x < dims[0]; x++)
    {
      input->SetScalarComponentFromDouble(x, y, 0, 0, 2.0);
    }
  }

  std::cout << "Input image: " << std::endl;
  PrintImage(input);

  vtkNew<vtkImageAlgorithmFilter> filter;
  filter->SetInputData(input);
  filter->Update();

  vtkImageData* output = filter->GetOutput();

  std::cout << "Output image: " << std::endl;
  PrintImage(output);

  return 0;
}

void PrintImage(vtkImageData* image)
{
  const int* dims = image->GetDimensions();

  for (int y = 0; y < dims[1]; y++)
  {
    for (int x = 0; x < dims[0]; x++)
    {
      double v = image->GetScalarComponentAsDouble(x, y, 0, 0);
      std::cout << v << " ";
    }
    std::cout << std::endl;
  }
}
